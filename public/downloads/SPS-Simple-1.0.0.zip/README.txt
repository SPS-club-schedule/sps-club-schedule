SPS 极简日程 1.0.0

Android 8.0 及以上；可与原 SPS 社团日程同时安装。

1. 解压后将 SPS-Simple-1.0.0.apk 发到安卓手机，点击安装。
2. 使用已有 SPS 账号登录。任务与网页、原 App 共用，本机登录信息独立。
3. 日历每格 15 分钟：长按空白后拖动创建；直接滑动滚动；双指缩放格子；也可点新建。
4. 大标题对应活动，小标题对应具体工作。小标题留空可为大标题安排独立日程，起止相同为 DDL。
5. 极简模式不标记完成，建议按提示关闭邮件提醒；关闭后，你的逾期也不会触发给部门负责人的邮件。
6. 右上角可切回完整模式。请保持 Android System WebView 或 Chrome 更新。

网页：https://sps-club-schedule.github.io/sps-club-schedule/?mode=simple#/simple
